package training;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author Pavithra
 *
 */
public class gmail {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Pavithra\\Downloads\\Selenium\\drivers\\chromedriver");
		WebDriver driver = (WebDriver) new ChromeDriver();
		

	}

}
