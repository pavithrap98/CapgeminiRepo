import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class number_occurance {
	public static void main(String[] args)
	{
		int count=0;
		String line = "Selenium is the most popular automation tool. Selenium is an open source tool";

		Pattern pattern = Pattern.compile("Selenium");

		Matcher matcher = pattern.matcher(line);
		while (matcher.find())
		{
		    count = count+1;
		}
		System.out.println(count);
	}

}
