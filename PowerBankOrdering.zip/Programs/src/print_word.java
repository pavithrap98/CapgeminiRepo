import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class print_word {
	public static void main(String[] args)
	{
		String line = "Selenium is the most popular automation tool. Selenium is an open source tool";

		Pattern pattern = Pattern.compile("tool");

		Matcher matcher = pattern.matcher(line);
		while (matcher.find())
		{
		    System.out.println(matcher.group());
		}
	}

}
