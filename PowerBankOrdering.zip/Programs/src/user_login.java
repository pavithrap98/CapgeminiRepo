import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class user_login extends setup{
	public static void main(String[] args) throws InterruptedException
	{
		System.out.println("Enter \n 1. user1 login \n 2. user2 login\n 3. user3 login\n");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		driver = initializeBrowser();
		loadProjectDataProperties();
		driver.get(prop.getProperty("url"));
		
		switch(n)
		{
		case 1: String user1 = prop.getProperty("user1");
				String pass1 = prop.getProperty("user1_password");
				login(user1, pass1);
				if(driver.findElement(By.xpath("//a[@title='dummy']")).isDisplayed())
					System.out.println("Logged in successfull");
				else
					System.out.println("Login failed");
				user_logout();
				break;
		case 2: String user2 = prop.getProperty("user2");
				String pass2 = prop.getProperty("user2_password");
				login(user2, pass2);
				if(driver.findElement(By.xpath("//a[@title='dummy']")).isDisplayed())
					System.out.println("Logged in successfull");
				else
					System.out.println("Login failed");
				user_logout();
				break;
		
		case 3: String user3 = prop.getProperty("user3");
				String pass3 = prop.getProperty("user3_password");
				login(user3, pass3);
				if(driver.findElement(By.xpath("//a[@title='dummy']")).isDisplayed())
					System.out.println("Logged in successfull");
				else
					System.out.println("Login failed");
				user_logout();
				break;
				
		}
	}
	
	public static void login(String user, String pass) throws InterruptedException
	{
		WebElement myaccount_hover = driver.findElement(By.xpath("//a[contains(text(),'My Account')]"));
		myaccount_hover.click();
		Thread.sleep(2000);
		WebElement signup_button = driver.findElement(By.xpath("//a[@id='signInBtn']"));
		signup_button.click();
		Thread.sleep(2000);
		WebElement username = driver.findElement(By.xpath("//input[@id='login-input']"));
		username.sendKeys(user);
		WebElement continue_button = driver.findElement(By.id("login-continue-btn"));
		continue_button.click();
		WebElement password = driver.findElement(By.id("login-password"));
		password.sendKeys(pass);
		WebElement login_button = driver.findElement(By.id("login-submit-btn"));
		login_button.click();
		
		
	}
	
	public static void user_logout() throws InterruptedException
	{
		
		WebElement user_dropdown = driver.findElement(By.xpath("//a[@title='dummy']"));
		user_dropdown.click();
		Thread.sleep(2000);
		WebElement logout_button = driver.findElement(By.id("logOut"));
		logout_button.click();
		if(driver.findElement(By.xpath("//a[contains(text(),'My Account')]")).isDisplayed())
			System.out.println("Logged out successfull");
		else
			System.out.println("Logout failed");
		driver.quit();
		
	}
	
	

}
