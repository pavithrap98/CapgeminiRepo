import java.util.Random;

public class unique_digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd = new Random();
	System.out.println(rnd.nextInt(999999));

	}

}
