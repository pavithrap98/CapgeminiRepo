package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;




public class login extends base{
	/*
	 * method for login
	 */
	
	public static void user_login(String user) throws InterruptedException
	{
		WebElement myaccount_hover = driver.findElement(By.xpath("//a[contains(text(),'My Account')]"));
		myaccount_hover.click();
		Thread.sleep(2000);
		WebElement signup_button = driver.findElement(By.xpath("//a[@id='signInBtn']"));
		signup_button.click();
		Thread.sleep(2000);
		WebElement username = driver.findElement(By.xpath("//input[@id='login-input']"));
		username.sendKeys(user);
		WebElement continue_button = driver.findElement(By.id("login-continue-btn"));
		continue_button.click();
		WebElement password = driver.findElement(By.id("login-password"));
		password.sendKeys(prop.getProperty("password"));
		WebElement login_button = driver.findElement(By.id("login-submit-btn"));
		login_button.click();
		
		if(driver.findElement(By.xpath("//a[@title='dummy']")).isDisplayed())
			System.out.println("Logged in successfull");
		else
			System.out.println("Login failed");
	}
	
	
	}