package methods;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class hotelBooking extends base{
	
	/*
	 * searching for hotels in a particular location
	 */
	public static void search_hotels()
	{
		WebElement Hotel_Icon = driver.findElement(By.xpath("//a[@id='booking_engine_hotels']//div"));
		Hotel_Icon.click();
		WebElement check_in = driver.findElement(By.id("BE_hotel_checkin_date"));
		check_in.click();
		WebElement checkIn_date = driver.findElement(By.id("21/03/2022"));
		checkIn_date.click();
		
		WebElement checkOut_date = driver.findElement(By.id("25/03/2022"));
		checkOut_date.click();
		WebElement search_button = driver.findElement(By.id("BE_hotel_htsearch_btn"));
		search_button.click();
		
		if(driver.findElement(By.xpath("//p[@class='matrix-label uprcse ng-binding']")).isDisplayed())
			System.out.println("Searching successfull");
		else
			System.out.println("Searching failed");
		
	}
	
	/*
	 * Booking of the hotel
	 */
	public static void book_hotel() throws InterruptedException
	{
		String defaultwin = driver.getWindowHandle();
		WebElement choose_room_button = driver.findElement(By.xpath("//div[@id='result0']//span[@class='new-blue-button medium choose-room-button nowrap ng-binding'][normalize-space()='Choose Room']"));
		choose_room_button.click();
		Set <String> windows = driver.getWindowHandles();
		Iterator <String> itr = windows.iterator();
		while(itr.hasNext())
		{
			String window = itr.next();
			driver.switchTo().window(window);
		}
		WebElement room_detail_page_choose_room_button = driver.findElement(By.id("choose-room-disable"));
		room_detail_page_choose_room_button.click();
		Thread.sleep(2000);
		WebElement book_now_button = driver.findElement(By.xpath("//li[@id='roomWrapper0001614560']//button[contains(@class,'choose-room-button')][normalize-space()='Book Now']"));
		book_now_button.click();
		
		if(driver.findElement(By.xpath("//div[@class='box hide-under-overlay mb-1 ng-scope']//h3[@class='box-title grad']")).isDisplayed())
			System.out.println("Booking successfull");
		else
			System.out.println("Booking failed");
		driver.close();
		driver.switchTo().window(defaultwin);
	}

}
