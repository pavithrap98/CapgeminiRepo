package methods;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class base {
	public static WebDriver driver;
	public static Properties prop;
	/*
	 * load chromedriver in maximized mode 
	 */
	
	public WebDriver initializeBrowser() 
	{
		
			
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		return driver;
		
	}
	/*
	 * load the property file
	 */
	
public void loadProjectDataProperties() {
		
		prop = new Properties();
		
		String projectPath = System.getProperty("user.dir");
		
		File file = new File(projectPath+"\\resources\\data.properties");
		try {
		
		FileInputStream fis = new FileInputStream(file);
		
		prop.load(fis);
		
		}catch(Throwable t) {
			
			System.out.println(t.getMessage());
			
		}
}

}
