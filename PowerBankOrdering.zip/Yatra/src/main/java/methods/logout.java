package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class logout extends base{
	public static void user_logout() throws InterruptedException
	{
		
		WebElement user_dropdown = driver.findElement(By.xpath("//a[@title='dummy']"));
		user_dropdown.click();
		Thread.sleep(2000);
		WebElement logout_button = driver.findElement(By.id("logOut"));
		logout_button.click();
		if(driver.findElement(By.xpath("//a[contains(text(),'My Account')]")).isDisplayed())
			System.out.println("Logged out successfull");
		else
			System.out.println("Logout failed");
		
	}

}
