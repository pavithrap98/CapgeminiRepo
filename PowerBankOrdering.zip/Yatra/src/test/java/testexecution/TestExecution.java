package testexecution;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import methods.base;
import methods.hotelBooking;
import methods.login;
import methods.logout;




public class TestExecution extends base
{
	public WebDriver driver;
	@BeforeSuite
	public void setup()
	{
	driver = initializeBrowser();
	loadProjectDataProperties();
	driver.get(prop.getProperty("url"));
	}
	
	@DataProvider (name = "test")
	public Object[][] dpMethod1(){
		return new Object[][] {{prop.getProperty("username")}};
	}
	
	
	@Test (dataProvider = "test")
	public void call_methods(String s1) throws InterruptedException
	{
		String str = s1;
		login.user_login(str);
		hotelBooking.search_hotels();
		hotelBooking.book_hotel();
		logout.user_logout();
		
		
	}
	

	@AfterSuite
	public void teardown()
	{
		driver.quit();
	}
	
}
