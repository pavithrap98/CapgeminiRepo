package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PowerBankCatalog {
WebDriver driver;
	
	public PowerBankCatalog(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(linkText="Xiaomi Mi PB10IZM 10000 mAh Power Bank")
	WebElement Xiomi;
	
	public void Xiomi()
	{
		Xiomi.click();
	}
	
	@FindBy(id="zebronics1056")
	WebElement Zebronics;
	
	public void Zebronics()
	{
		Zebronics.click();
	}
	
	@FindBy(id="syska2257")
	WebElement Syska;
	
	public void Syska()
	{
		Syska.click();
	}
	
	@FindBy(id="latestandexpectedprice15000300001")
	WebElement price;
	
	public void price()
	{
		price.click();
	}
	
	@FindBy(id="probatterycapacityinmah1500030000")
	WebElement battery15_30;
	
	public void battery15_30()
	{
		battery15_30.click();
	}
	
	@FindBy(id="probatterycapacityinmah80010120000")
	WebElement battery80_12;
	
	public void battery80_12()
	{
		battery80_12.click();
	}
	
	@FindBy(id="connectortypepinoutslugconnectorpinoutslugusb")
	WebElement usb;
	
	public void usb()
	{
		usb.click();
	}
	
	@FindBy(id="connectortypepinoutslugconnectorpinoutslugmicrousb")
	WebElement microusb;
	
	public void microusb()
	{
		microusb.click();
	}
	
	@FindBy(linkText="Xiaomi Mi Power Bank 3i 10000 mAh Power Bank")
	WebElement Xiomipowerbank;
	
	public void Xiomipowerbank() throws InterruptedException
	{
		Thread.sleep(2000);
		Xiomipowerbank.click();
	}

}
