package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllParameters {
	
	WebDriver driver;
	
	public AllParameters(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(id="nikon1617")
	WebElement NikonClick;
	
	public void NikonClick() {
		NikonClick.click();
		
	}
	
	@FindBy(id="canon1569")
	WebElement CanonClick;
	
	public void CanonClick() {
		CanonClick.click();
		
	}
	
	@FindBy(id="proeffectiveresolution5010001")
	WebElement MP1Click;
	
	public void MP1Click() {
		
		MP1Click.click();
		
	}
	
	@FindBy(id="proeffectiveresolution10010001")
	WebElement MP2Click;
	
	public void MP2Click() {
		
		MP2Click.click();
		
	}
	
	@FindBy(xpath="//input[@id='prostandardbatterytypeaa']")
	WebElement AAClick;
	
	public void AAClick() {
		
		AAClick.click();
		
	}
	
	@FindBy(id="prostandardbatterytypeaaa")
	WebElement AlkalineClick;
	
	public void AlkalineClick() {
		
		AlkalineClick.click();
		
	}
	
	@FindBy(id="providresolutionsd640x480")
	WebElement SDClick;
	
	public void SDClick() {
		
		SDClick.click();
		
	}
	
	@FindBy(id="providresolutionhd1280x720")
	WebElement HDClick;
	
	public void HDClick() {
		
		HDClick.click();
		
	}
	
	@FindBy(id="prowifiyes")
	WebElement WifiClick;
	
	public void WifiClick() {
		
		WifiClick.click();
		
	}
	
	@FindBy(id="prohdmiyes")
	WebElement HDMIClick;
	
	public void HDMIClick() {
		
		HDMIClick.click();
		
	}
	
	@FindBy(id="proopticalzoom5010001")
	WebElement Zoom1Click;
	
	public void Zoom1Click() {
		
		Zoom1Click.click();
		
	}
	
	@FindBy(id="proopticalzoom10010001")
	WebElement Zoom2Click;
	
	public void Zoom2Click() {
		
		Zoom2Click.click();
		
	}
	
	@FindBy(xpath="//span[@class='btn_prcList_sn flt-rt target_link_external impressions_gts']")
	WebElement StoreClick;
	
	public void StoreClick() {
		
		StoreClick.click();
		
	}

}