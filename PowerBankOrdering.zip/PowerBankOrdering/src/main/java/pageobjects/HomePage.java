package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
WebDriver driver;
	
	public HomePage(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="autoSuggestTxtBox")
	WebElement SearchBar;
	
	public void SearchBar()
	{
		SearchBar.sendKeys("Vivo");;
	}
	
	@FindBy(id = "main_auto_search")
	WebElement SearchButton;
	
	public void searchButton() throws InterruptedException
	{
		Thread.sleep(2000);
		SearchButton.click();
	}
	
	@FindBy(id="floatingNavLogin")
	WebElement Login_SignupOption;
	
	public void Login_SignupOption()
	{
		Login_SignupOption.click();
	}
	
	@FindBy(id="comment_button")
	WebElement login;
	
	public void login()
	{
		login.click();
	}
	
	@FindBy(xpath="//img[@width='auto']")
	WebElement logo;
	
	public void logo()
	{
		logo.click();
	}
	
	@FindBy(xpath="//ul[@class='home-top-links']//span[@title='Power Banks'][normalize-space()='Power Banks']")
	WebElement powerbank;
	
	public void powerbank()
	{
		powerbank.click();
	}
	
	@FindBy(id="autoSuggestTxtBox")
	WebElement SearchBars;

	public void SearchBars() throws InterruptedException {
		SearchBar.sendKeys("nikon d5600");
		Thread.sleep(2000);
	}
	
	@FindBy(xpath="//ul[@class='home-top-links']//span[@title='Power Banks']")
	WebElement powerBank;
	
	public void powerBank() {
		powerBank.click();
	}
	
	@FindBy(xpath="//div[@class='float_notify_wrap']//div[@class='fav_notify']")
	WebElement favourites;
	
	public void favourites() {
		favourites.click();
	}
	
	@FindBy(id="autoSuggestTxtBox")
	WebElement Search;
	
	
	public void Search() {
		
		Search.click();
	}
	
	@FindBy(xpath="//input[@id='autoSuggestTxtBox']")
	WebElement SearchBox;
	
	public void SearchBox() {
		
		SearchBox.sendKeys("Apple");
		
	}
	
	
	@FindBy(xpath="//span[normalize-space()='Login/Signup']")
	WebElement LoginButton;
	
	public void LoginButton() {
		
		LoginButton.click();
		
	}
	
	@FindBy(id="comment_button")
	WebElement Login;
	
	public void Login() {
		
		Login.click();
		
	}
	
	@FindBy(xpath="//input[@id='autoSuggestTxtBox']")
	WebElement Valid;
	
	public void Valid() {
		
		Valid.sendKeys("Samsung");
		
	}
	
	@FindBy(xpath="//input[@id='autoSuggestTxtBox']")
	WebElement Invalid;
	
	public void Invalid() {
		
		Valid.sendKeys("hsegfwbd");
		
	}
	
	@FindBy(xpath="//ul[@class='home-top-links']//span[@title='Cameras'][normalize-space()='Cameras']")
	WebElement GoQuickly;
	
	public void GoQuickly() {
		
		GoQuickly.click();
		
	}
	
	@FindBy(xpath="//a[normalize-space()='Polaroid Snap Digital Instant Photo...']")
	WebElement ProductClick;
	
	public void ProductClick() {
		
		ProductClick.click();
	
	}
	
	@FindBy(xpath="//span[@class='store_prc']")
	WebElement PriceCheck;
	
	public void PriceCheck() {
		
		PriceCheck.isDisplayed();
		
	}
	
	@FindBy(xpath="//span[@class='spec_compr topScroll']")
	WebElement SpecCheck;
	
	public void SpecCheck() {
		
		SpecCheck.click();
		
	}
	
	@FindBy(xpath = "//div[@class='lang-list ']")
	WebElement Dropdown;

	@FindBy(xpath = "//span[@title='हिंदी']")
	WebElement Hindi;

	public void Hindi() {
		Hindi.click();
	}

	public void Dropdown() {
		Actions a = new Actions(driver);
		a.moveToElement(Dropdown).perform();

	}

	@FindBy(xpath = "//span[@title='தமிழ்']")
	WebElement Tamil;

	public void Tamil() {
		Tamil.click();
	}

	@FindBy(xpath = "//span[@title='English']")
	WebElement English;

	public void English() {
		English.click();

	}

	@FindBy(xpath = "//span[@title='Mobiles']")
	WebElement Mobiles;

	public void Mobiles() {
		Mobiles.click();
	}

	@FindBy(xpath = "//img[@width='auto']")
	WebElement HomepageLogo;

	public void HomepageLogo() {
		HomepageLogo.click();
	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Laptops'][normalize-space()='Laptops']")
	WebElement Laptops;

	public void Laptops() {
		Laptops.click();
	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Tablets'][normalize-space()='Tablets']")
	WebElement Tablets;

	public void Tablets() {
		Tablets.click();

	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Cameras'][normalize-space()='Cameras']")
	WebElement Cameras;

	public void Cameras() {
		Cameras.click();

	}

	@FindBy(xpath = "//span[@title='Television']")
	WebElement Television;

	public void Television() {
		Television.click();

	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Home Theaters'][normalize-space()='Home Theaters']")
	WebElement HomeTheaters;

	public void HomeTheaters() {
		HomeTheaters.click();

	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Power Banks'][normalize-space()='Power Banks']")
	WebElement PowerBanks;

	public void PowerBanks() {
		PowerBanks.click();

	}

	@FindBy(xpath = "//span[@title='Smart Watches']")
	WebElement SmartWatches;

	public void SmartWatches() {
		SmartWatches.click();

	}

	@FindBy(xpath = "//span[@title='Washing Machines']")
	WebElement WashingMachines;

	public void WashingMachines() {
		WashingMachines.click();

	}

	@FindBy(xpath = "//ul[@class='home-top-links']//span[@title='Air Conditioners'][normalize-space()='Air Conditioners']")
	WebElement AirConditioners;

	public void AirConditioners() {
		AirConditioners.click();

	}

	@FindBy(id = "floatingNavLogin")
	WebElement LoginSignup;

	public void LoginSignup() {
		LoginSignup.click();

	}

	@FindBy(xpath = "//div[@class='tikr-pnl']")
	WebElement Bar;

	public void Bar() {
		Bar.click();

	}

	@FindBy(xpath = "//div[@class='noUi-handle noUi-handle-upper']")
	WebElement Max;

	public WebElement Max() {

		return Max;
	}

	@FindBy(xpath = "//div[@class='noUi-handle noUi-handle-lower']")
	WebElement Min;

	public WebElement Min() {

		return Min;
	}

	@FindBy(xpath = "//div[@class='ticker_data_panel']//div[@id='mobile']")
	WebElement FindMobile;

	public void FindMobile() {
		FindMobile.click();
	}

	@FindBy(css = "body > div:nth-child(1) > div:nth-child(12) > form:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(5) > div:nth-child(8) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > span:nth-child(1)")
	WebElement Price;

	public void Price() {
		Price.click();
	}

	@FindBy(xpath = "//span[normalize-space()='About Us']")
	WebElement AboutUs;

	public void AboutUs() {
		AboutUs.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Contact Us']")
	WebElement ContactUs;

	public void ContactUs() {
		ContactUs.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Terms & Conditions']")
	WebElement TermsConditions;

	public void TermsConditions() {
		TermsConditions.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Privacy']")
	WebElement Privacy;

	public void Privacy() {
		Privacy.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Feedback']")
	WebElement Feedback;

	public void Feedback() {
		Feedback.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Home']")
	WebElement Home;

	public void Home() {
		Home.click();
	}

	@FindBy(xpath = "//span[normalize-space()='Sitemap']")
	WebElement Sitemap;

	public void Sitemap() {
		Sitemap.click();
	}

	@FindBy(xpath = "//span[@class='target_link category-row']//div[contains(text(),'Mobiles')]")
	WebElement mobiles;

	public void mobiles() {
		mobiles.click();
	}

	@FindBy(xpath = "//div[@class='inner_pro']//span[2]")
	WebElement laptops;

	public void laptops() {
		laptops.click();
	}

	@FindBy(xpath = "//div[@class='home_top_news_pnl']//span[3]")
	WebElement tablets;

	public void tablets() {
		tablets.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[4]")
	WebElement audio;

	public void audio() {
		audio.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[5]")
	WebElement smartwatches;

	public void smartwatches() {
		smartwatches.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[6]")
	WebElement televisions;

	public void televisions() {
		televisions.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[7]")
	WebElement airconditioners;

	public void airconditioners() {
		airconditioners.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[8]")
	WebElement refrigerators;

	public void refrigerators() {
		refrigerators.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[9]")
	WebElement washingmachines;

	public void washingmachines() {
		washingmachines.click();
	}

	@FindBy(xpath = "//div[@class='outer_wrap content_wrap']//span[10]")
	WebElement cameras;

	public void cameras() {
		cameras.click();
	}
	
	@FindBy(linkText="SIGN UP")
	WebElement Sign_up;
	
	public void Sign_up() {
		Sign_up.click();
	}
	
	@FindBy(id="floatingNavLogin")
	WebElement SignUpClick;
	
	public void SignUpClick() {
		SignUpClick.click();
	}
	
	@FindBy(id="emailId_signup")
	WebElement Email_add;
	
	public void Email_add(String emailaddress) {
		Email_add.sendKeys(emailaddress);
	}

	@FindBy(id="password_signup")
	WebElement Password;
	
	public void Password(String passwords) {
		Password.sendKeys(passwords);
	}
	
	@FindBy(id="comment_button_signup")
	WebElement SignUp;
	
	public void SignUp() throws InterruptedException {
		SignUp.click();
		Thread.sleep(3000);
	}
	
	@FindBy(id="emailId")
	WebElement Emailid;
	
	public void Emailid(String emailaddressLogin) {
		Emailid.sendKeys(emailaddressLogin);
	}
	
	@FindBy(id="password")
	WebElement Password_login;
	
	public void Password_login(String passwordLogin ) {
		Password_login.sendKeys(passwordLogin);
	}
	
	
	@FindBy(id="floatingNavLogin")
	WebElement SignUpClick2;
	
	public void SignUpClick2() {
		SignUpClick2.click();
	}
	
	@FindBy(css="div[class='signup_with'] div[class='facebook_login']")
	WebElement FacebookSignup;
	
	public void FacebookSignup() {
		FacebookSignup.click();
	}
	
	@FindBy(css=".variousCommon.links[rel='nofollow']")
	WebElement GoogleSignup;
	
	public void GoogleSignup() {
		GoogleSignup.click();
	}
	
	@FindBy(css="div[class='signup_with'] div[class='google_login']")
	WebElement GoogleSignUp;
	
	public void GoogleSignUp() {
		GoogleSignUp.click();
	}
	
	@FindBy(css=".variousCommon.links[rel='nofollow']")
	WebElement LoginFacebook;
	
	public void LoginFacebook() {
		LoginFacebook.click();
	}
	
	@FindBy(css="div[class='login_with'] div[class='facebook_login'] div[class='socialicn']")
	WebElement FacebookLogin;
	
	public void FacebookLogin() {
		FacebookLogin.click();
	}
	
	@FindBy(css=".variousCommon.links[rel='nofollow']")
	WebElement LoginGoogle;
	
	public void LoginGoogle() {
	    LoginGoogle.click();
	}
	
	@FindBy(css="div[class='login_with'] div[class='google_login'] div[class='socialicn']")
	WebElement GoogleLogin;
	
	public void GoogleLogin() {
		GoogleLogin.click();
	}
	
	@FindBy(xpath="//span[normalize-space()='Login/Signup']")
	WebElement ForgotLogin;
	
	public void ForgotLogin() {
		
		
		ForgotLogin.click();
	}
	
	@FindBy(id="emailId")
	WebElement ForgotEmail;
	
	public void ForgotEmail(String emailaddressforgot) {
		ForgotEmail.sendKeys(emailaddressforgot);
	}
	
	@FindBy(id="password")
	WebElement ForgotPassword;
	
	public void ForgotPassword(String forgotpassword) {
		ForgotPassword.sendKeys(forgotpassword);
	}
	
	@FindBy(linkText = "Forgot Password?")
	WebElement ForgotClick;
	
	public void ForgotClick() {
		ForgotClick.click();
	}
	
	@FindBy(id="emailId_forgot")
	WebElement ForgotMail;
	
	public void ForgotMail(String newmail) {
		ForgotMail.sendKeys(newmail);
	}

	
	
	@FindBy(css="a[data-popup-open='popup-2']")
	WebElement forgotpassword;
	
	public void forgotpassword() {
		forgotpassword.click();
	}
	
	@FindBy(xpath="//input[@value='Reset Password']")
	WebElement ResetClick;
	
	public void ResetClick() {
		ResetClick.click();
	}
	
	@FindBy(xpath="//div[@class='msgnot']")
	WebElement LoggedInIcon;
	
	public void LoggedInIcon() {
		LoggedInIcon.click();
	}
	
	@FindBy(xpath="//a[contains(text(),'Manage Profile')]")
	WebElement MyAccount;
	
	public void MyAccount() {
		MyAccount.click();
	}
	
	@FindBy(xpath="//input[@id='contact_name']")
	WebElement ChangeName;
	
	public void ChangeName() throws InterruptedException {
		ChangeName.clear();
		Thread.sleep(2000);
		ChangeName.sendKeys("Miral Shah");
	}
	
	@FindBy(xpath="//input[@id='contact_email']")
	WebElement ChangeEmail;
	
	public void ChangeEmail() {
		ChangeEmail.sendKeys("spotmiral31@gmail.com");
	}
	
	@FindBy(xpath="//a[normalize-space()='Save Changes']")
	WebElement SaveChanges;
	
	public void SaveChanges() {
		SaveChanges.click();
	}
	
	@FindBy(id="emailId")
	WebElement Emailad;
	
	public void Emailad() {
		Emailad.sendKeys("spotmiral31@gmail.com");
	}
	
	@FindBy(id="password")
	WebElement Passd;
	
	public void Passd() {
		Passd.sendKeys("miral31");
	}
	
	@FindBy(xpath="//a[normalize-space()='Resend confirmation email.']")
	WebElement ConfirmMail;
	
	public void ConfirmMail() {
		ConfirmMail.click();
	}
	
	@FindBy(id="OldPassword")
	WebElement Oldpass;
	
	public void Oldpass() {
	Oldpass.sendKeys("miral31");
	}
	
	@FindBy(id="NewPassword")
	WebElement newpass;
	
	public void newpass() {
		newpass.sendKeys("miral31");
	}
	
	@FindBy(xpath="//a[normalize-space()='Change password']")
	WebElement savepass;
	
	public void savepass() {
		savepass.click();
	}
	
}
