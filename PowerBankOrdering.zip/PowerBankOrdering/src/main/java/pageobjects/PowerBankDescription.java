package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PowerBankDescription {
WebDriver driver;
	
	public PowerBankDescription(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//span[@class='btn_prcList_sn flt-rt target_link_external impressions_gts']")
	WebElement gotostore;
	
	public void gotostore()
	{
		gotostore.click();
	}

}
