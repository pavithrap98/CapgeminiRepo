package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Cameras {
	WebDriver driver;

	public Cameras(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@title='Nikon']//div[@class='item']")
	WebElement brandNikon;
	
	public void brandNikon() {
		brandNikon.click();
	}
}
