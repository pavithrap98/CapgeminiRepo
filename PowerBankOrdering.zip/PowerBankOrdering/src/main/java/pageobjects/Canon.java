package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Canon {
	WebDriver driver;

	public Canon(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//img[@title='Nikon D5600 (AF-P 18-55mm f/3.5-f/5.6G VR Kit Lens) Digital SLR Camera']")
	WebElement Product;

	public void Product() throws InterruptedException {
		Thread.sleep(2000);
		Product.click();

	}

	@FindBy(xpath="//span[@class='spec_compr topScroll']")
	WebElement Specifications;

	public void Specifications() {
		Specifications.click();
	}
}