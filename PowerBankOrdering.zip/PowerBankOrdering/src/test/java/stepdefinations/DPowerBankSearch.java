package stepdefinations;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.Set;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.cucumber.listener.Reporter;

import base.Base;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import pageobjects.HomePage;
import pageobjects.PowerBankCatalog;
import pageobjects.PowerBankDescription;
import pageobjects.PowerBankList;

@RunWith(Cucumber.class)
public class DPowerBankSearch extends Base {

	WebDriver driver;

	@Before("@search")
	public void setup() {

		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));

	}

	@After("@search")
	public void teardown(Scenario scenario) throws IOException {
		if (scenario.isFailed()) {
			try {
				String screenshotName = scenario.getName().replaceAll(" ", "_");
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				File screenshot_with_scenario_name = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				File destinationPath = new File("C:\\Users\\Pavithra\\eclipse-workspace\\PowerBankOrdering\\screenshots\\"+screenshotName+scenario.getId()+".png");

				Files.copy(screenshot_with_scenario_name.toPath(), destinationPath.toPath());

				Reporter.addScreenCaptureFromPath(destinationPath.toString());
				Reporter.addScenarioLog(screenshotName);

				scenario.embed(screenshot, "image/png");

			} catch (Exception e) {
				System.out.println("Failed to take screenshot");
			}
		}

		driver.quit();
	}

	@Given("^I visit the website$")
	public void i_visit_the_website() {
		driver.get(prop.getProperty("url"));

	}

	@When("^I click on Search on search bar$")
	public void i_click_on_search_on_search_bar() throws InterruptedException {
		HomePage page = new HomePage(driver);
		page.searchButton();
		Thread.sleep(3000);

	}

	@And("^I should click on logo to redirect to home page$")
	public void i_should_click_on_logo_to_redirect_to_home_page() {
		HomePage page = new HomePage(driver);
		page.logo();
	}

	@Then("^I should redirect to home page of the website$")
	public void i_should_redirect_to_home_page_of_the_website() {
		Assert.assertTrue(driver.findElement(By.xpath("//img[@width='auto']")).isDisplayed());

	}

	@Then("^I should get search results$")
	public void i_should_be_able_to_recieve_results_according_to_my_search() {
		String actualstatus = null;
		String expectedstatus = "Success";
		if (driver.getTitle().equals("vivo | 91mobiles.com")) {
			actualstatus = "Success";
		} else
			actualstatus = "Failure";

		try {
			Assert.assertEquals(actualstatus, expectedstatus);
		}

		catch (Exception e) {
			System.out.println(" Failed Test Case");
		}

	}

	@And("^I should be able to enter keywords on search bar$")
	public void i_should_be_able_to_enter_keywords_on_search_bar() {
		HomePage page = new HomePage(driver);
		page.SearchBar();

	}

	@When("^I Click on the Login/SignUp optionssss$")
	public void i_click_on_the_loginsignup_options() throws InterruptedException {
		HomePage page = new HomePage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(1000);
		page.Login_SignupOption();
		Thread.sleep(2000);

	}

	@Then("^I should login with valid credentials$")
	public void i_should_login_with_valid_credentials() {
		HomePage page = new HomePage(driver);
		driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("pavithra_username"));
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("pavithra_password"));
		page.login();

	}

	@And("^I should access the home page as registered User$")
	public void i_should_access_the_home_page_as_registered_user() {
		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='notify_wrap']//div[@class='fav_notify']")).isDisplayed());

	}

	@Then("^I should get the results based onn (.+)$")
	public void i_should_get_the_results_based_onn(String expectedresults) throws InterruptedException {
		String actualresult = null;

		Thread.sleep(2000);
		if (driver.findElement(By.xpath("//div[@class='noserch_title']")).getText().equals("Sorry, no results found")) {
			actualresult = "failure";
		} else
			actualresult = "success";

		Assert.assertEquals(actualresult, expectedresults);

	}

	@And("^I should enter the (.+) on the search bar in home page$")
	public void i_should_enter_the_on_the_search_bar_in_home_page(String keywords) {
		driver.findElement(By.id("autoSuggestTxtBox")).sendKeys(keywords);

	}

	@Then("^I Should get the power bank within that price range$")
	public void i_should_get_the_power_bank_within_that_price_range() {
		String result=null;
		if(driver.findElement(By.xpath("//div[@class='noserch_title']")).getText().equals("Sorry, no results found"))
		{
			 result = "fail";
		}
		else {
			result = "true";
		}
		Assert.assertEquals(result,"true");
	}

	@And("^I Should enter the price range of the power bank$")
	public void i_should_enter_the_price_range_of_the_power_bank() {
		
		driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("Power Banks Under 1000");

	}
	
	 @And("^I Should enter the power bank by its feature$")
	    public void i_should_enter_the_power_bank_by_its_feature() {
		 driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("LED indicators Power Banks");
	        
	    }
	 
	 @Then("^I Should get the power bank based on the featuress$")
	    public void i_should_get_the_power_bank_based_on_the_feature() {
		 String result=null;
			if(driver.findElement(By.xpath("//div[@class='noserch_title']")).getText().equals("Sorry, no results found"))
			{
				 result = "fail";
			}
			else {
				result = "true";
			}
			Assert.assertEquals(result,"true");
	        
	    }
	 

	    @When("^I Select All Power Bank from left panel$")
	    public void i_select_all_power_bank_from_left_panel() {
	    	PowerBankList pbl = new PowerBankList(driver);
	    	pbl.allpowerbanks();
	    	
	        
	    }

	    @Then("^I should get the all power banks catalog$")
	    public void i_should_get_the_all_power_banks_catalog() {
	    	Assert.assertTrue(driver.getTitle().equals("Power Banks Price List in India | 91mobiles.com"));
	        
	    }

	    @Then("^I Should get particular product page$")
	    public void i_should_get_particular_product_page() throws InterruptedException {
	    	Assert.assertEquals(driver.findElement(By.linkText("Xiaomi Mi PB10IZM 10000 mAh Power Bank")).getText(),"Xiaomi Mi PB10IZM 10000 mAh Power Bank");
	    	Thread.sleep(2000);
	    }

	    @And("^I Should click on power bank from Go Quickly to options$")
	    public void i_should_click_on_power_bank_from_go_quickly_to_options() {
	    	HomePage page = new HomePage(driver);
	    	page.powerbank();
	       
	    }
	    
	    @Then("^I Should select power bank from Go Quickly to options$")
	    public void i_Should_select_power_bank_from_Go_Quickly_to_options() {
	    	HomePage page = new HomePage(driver);
	    	page.powerbank();
	    }

	    @And("^I Click select any power bank$")
	    public void i_click_select_any_power_bank() {
	    	PowerBankCatalog pbc = new PowerBankCatalog(driver);
	    	pbc.Xiomi();
	       
	    }
	    
	    @Given("^I visit 91Mobiles website$")
	    public void i_visit_91mobiles_website() {
	        driver.get(prop.getProperty("url"));    
	        }
		
		@And("^I should access the home page$")
		public void i_should_access_the_home_page() {
			HomePage page = new HomePage(driver);
			page.logo();
		}
		
		
		@Then("^I should get the power bank brands according to (.+) and (.+)$")
	    public void i_should_get_the_power_bank_brands_according_to_and(String keyword1, String keyword2) throws InterruptedException {
			String expected = "true";
			String actual = null;
			JavascriptExecutor js = (JavascriptExecutor) driver;
			switch(keyword1)
			{
			case "Syska":js.executeScript("window.scrollTo(0,-300)"); Thread.sleep(2000);
			if( (driver.findElement(By.xpath("//span[normalize-space()='Syska']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='Zebronics']")).isDisplayed()))
			{
				actual="true";
			}
			else
				actual="false";
			break;
			
			case "1500-3000":js.executeScript("window.scrollTo(0,-300)"); Thread.sleep(2000);
				if(driver.findElement(By.xpath("//span[normalize-space()='Rs. 1,500 - Rs. 3,000']")).isDisplayed())
				{
					actual="true";
				}
				else
					actual="false";
				break;
				
			case "1500-3000mah":js.executeScript("window.scrollTo(0,-400)");Thread.sleep(2000);
				if( (driver.findElement(By.xpath("//span[normalize-space()='1500-3000 mAh']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='8001-12000 mAh']")).isDisplayed()))

				{
					actual="true";
				}
				else
					actual="false";
				break;
				
			case "USB":	js.executeScript("window.scrollTo(0,-600)"); Thread.sleep(2000);
			if( (driver.findElement(By.xpath("//span[normalize-space()='USB']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='Micro USB']")).isDisplayed()))

			{
				actual="true";
			}
			else
				actual="false";
			break;
			
			
			}
			
			Assert.assertEquals(actual, expected);
	    }

		 @And("^I should select multiple brands filter as (.+) and (.+)$")
		    public void i_should_select_multiple_brands_filter_as_and(String keyword1, String keyword2) throws InterruptedException {
	    	PowerBankCatalog pbc = new PowerBankCatalog(driver);
	    	JavascriptExecutor js = (JavascriptExecutor) driver;
			
			switch(keyword1)
			{
			case "Syska":	
			
			js.executeScript("window.scrollTo(0,300)");
			Thread.sleep(2000);
			pbc.Zebronics();
	    	pbc.Syska();
	    	Thread.sleep(2000);
	    	break;
	    	
			case "1500-3000":
			js.executeScript("window.scrollTo(0,300)");
			Thread.sleep(2000);
			pbc.price();
	    	Thread.sleep(2000);
	    	break;
	    	
			case "1500-3000mah":
			js.executeScript("window.scrollTo(0,400)");
			Thread.sleep(2000);
			pbc.battery15_30();
	    	pbc.battery80_12();
	    	Thread.sleep(2000);
	    	break;
	    	
			case "USB":
			js.executeScript("window.scrollTo(0,600)");
			Thread.sleep(2000);
			pbc.usb();
	    	pbc.microusb();
	    	Thread.sleep(2000);
	    	break;
			}
	    	
	        
	    }
	    
	    @When("^I Should click on All Power Bank from left panel$")
	    public void i_should_click_on_all_power_bank_from_left_panel() {
	    	PowerBankList pbl = new PowerBankList(driver);
	    	pbl.allpowerbanks();
	   
	    }
	    
	    @Then("^I should get the catalog of all the power banks$")
	    public void i_should_get_the_catalog_of_all_the_power_banks(){
	    	Assert.assertTrue(driver.getTitle().equals("Power Banks Price List in India | 91mobiles.com"));
	        
	    }
	    
	    @When("^I Click on the available stores$")
	    public void i_click_on_the_available_stores() {
	    	  PowerBankDescription pbd = new PowerBankDescription(driver);
	    	  Set<String> id = driver.getWindowHandles();
		  		Iterator<String> itr = id.iterator();
		  		@SuppressWarnings("unused")
				String mainw = itr.next();
		  		String child = itr.next();
		  		driver.switchTo().window(child);
		  		Assert.assertEquals(driver.getTitle(), "Xiaomi Mi Power Bank 3i 10000 mAh Power Bank price in India | 91mobiles.com");
		  	
	          pbd.gotostore();
	    	
	        
	    }

	    @Then("^I should be redirected to particular external website$")
	    public void i_should_be_redirected_to_particular_external_website() {
	    	Set<String> id = driver.getWindowHandles();
	  		Iterator<String> itr = id.iterator();
	  		@SuppressWarnings({ "unused" })
			String mainw = itr.next();
	  		@SuppressWarnings("unused")
			String child = itr.next();
	  		String child2 = itr.next();
	  		driver.switchTo().window(child2);
	      Assert.assertEquals(driver.getTitle(), "Mi 3i 10000 mAh Power Bank (Fast Charging, 18W) Price in India - Buy Mi 3i 10000 mAh Power Bank (Fast Charging, 18W) online at Flipkart.com");
	    }
	    
	    @And("^I should select any of the power bank from catalog$")
	    public void i_should_select_any_of_the_power_bank_from_catalog() throws InterruptedException {
	    	PowerBankCatalog pbc = new PowerBankCatalog(driver);
	    	pbc.Xiomipowerbank();
	        
	    }
	    
	    @When("^I enter the valid credentials$")
	    public void i_enter_the_valid_credentials() {
	    	HomePage page = new HomePage(driver);
	    	driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("pavithra_username"));
			driver.findElement(By.id("password")).sendKeys(prop.getProperty("pavithra_password"));
			page.login();
	        
	    }

	    @Then("^I should logged in to the website$")
	    public void i_should_logged_in_to_the_website() {
	    	Assert.assertTrue(driver.findElement(By.xpath("//div[@class='notify_wrap']//div[@class='fav_notify']")).isDisplayed());
	      
	    }

	    @And("^I should click on login/signup option available in home page$")
	    public void i_should_click_on_loginsignup_option_available_in_home_page() throws InterruptedException {
	    	HomePage page = new HomePage(driver);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
			Thread.sleep(1000);
			page.Login_SignupOption();
			Thread.sleep(2000);
	 
	    }

}