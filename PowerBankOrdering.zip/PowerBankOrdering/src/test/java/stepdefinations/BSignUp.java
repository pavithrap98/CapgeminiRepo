package stepdefinations;

import java.io.File;
import java.nio.file.Files;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.Reporter;

import base.Base;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import pageobjects.HomePage;

@RunWith(Cucumber.class)
public class BSignUp extends Base {
	WebDriver driver;
    @After("@MyAccount")
    public void TearDown(Scenario scenario) {
    	if (scenario.isFailed()) {
            try {
                String screenshotName = scenario.getName().replaceAll(" ", "_");
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                File screenshot_with_scenario_name = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

 

                File destinationPath = new File("C:\\Users\\Pavithra\\eclipse-workspace\\PowerBankOrdering\\screenshots\\"+screenshotName+scenario.getId()+".png");

 

                Files.copy(screenshot_with_scenario_name.toPath(), destinationPath.toPath());

 

                Reporter.addScreenCaptureFromPath(destinationPath.toString());
                Reporter.addScenarioLog(screenshotName);

 

                scenario.embed(screenshot, "image/png");

 

            } catch (Exception e) {
                System.out.println("Failed to take screenshot");
            }
        }

 

        driver.quit();
    	
    }
	@Before("@MyAccount")
	public void setup() {
		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));
	}

	@Given("^User visit the 91Mobiles website2$")
	public void user_visit_the_91mobiles_website() {
		driver.get(prop.getProperty("url"));

	}

	@When("^I click on 'Login/Signup' Option on the Home-Page2$")
	public void i_click_on_loginsignup_option_on_the_home_page2() throws InterruptedException {
		HomePage page = new HomePage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		page.SignUpClick();
		Thread.sleep(2000);
		
	}

	 @Then("^I should be able to click on SignUp2$")
	    public void i_should_be_able_to_click_on_signup2() {
		 HomePage page = new HomePage(driver);
			page.Sign_up();

	       
	    }
	 
    @Then("^I should be able to Enter valid email address2 as (.+)$")
    public void i_should_be_able_to_enter_valid_email_address2_as(String emailaddress) {
    	HomePage page = new HomePage(driver);
    	page.Email_add(emailaddress);
    }

    @And("^(.+) into password field2$")
    public void into_password_field2(String passwords) {
    	HomePage page = new HomePage(driver);
    	page.Password(passwords);
    }
    
    @And("^I should be able to Click2 on 'SignUp'$")
    public void i_should_be_able_to_click2_on_signup() throws InterruptedException {
    	HomePage page = new HomePage(driver);
		page.SignUp();

    }

    
    @Then("^I must be redirected to the Home Page2 (.+)$")
    public void i_must_be_redirected_to_the_home_page2(String expectedresults) {
    	String actualResult = null;
    	String element = driver.findElement(By.id("errCon_signup")).getText();
    	if (element.equals("Please enter a valid email address.")) {
    		actualResult = "failure";	
    	}
    	else {
    		actualResult = "success";}
   Assert.assertEquals(expectedresults, actualResult);
    	}



    @When("^I click on 'Login/Signups' Option on the Home Page2$")
    public void i_click_on_loginsignups_option_on_the_home_page2() throws InterruptedException {
    	HomePage page = new HomePage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		page.SignUpClick2();
		Thread.sleep(2000);
       
    
 
}
    
    @Then("^I should click on Sign-Up2$")
    public void i_should_click_on_signup2() {
    	HomePage page = new HomePage(driver);
		page.Sign_up();
 
    }

    @Then("^I should Click on Facebook Icon to signup with Facebook$")
    public void i_should_click_on_facebook_icon_to_signup_with_facebook() {
    	HomePage page = new HomePage(driver);
    	page.FacebookSignup();
   
}

/*@Then("^I Enter the details and signup with Facebook$")
public void i_enter_the_details_and_signup_with_facebook() {
}

@And("^I Click on SignUp option $")
public void i_click_on_signup_option() {
    
}

@And("^I am directed to Signup with Facebook page$")
public void i_am_directed_to_signup_with_facebook_page() {
}

@And("^Redirected to the Home Page$")
public void redirected_to_the_home_page() {
}*/


    @When("^I click on 'Logins/Signup' Option on the Home Page2$")
    public void i_click_on_loginssignup_option_on_the_home_page2() {
    	HomePage page = new HomePage(driver);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		page.SignUpClick();
    }
    
    @Then("^I click on sign-up2$")
    public void i_click_on_signup2() {
    	HomePage page = new HomePage(driver);
		page.Sign_up();

    }

    @Then("^I should Click on Google Icon to signup with Facebook$")
    public void i_should_click_on_google_icon_to_signup_with_facebook() {
    	HomePage page = new HomePage(driver);
    	page.GoogleSignUp();
        
    }
    
    @When("^I click on 'Login/Signup' Option on the HomePage2$")
	public void i_click_on_loginsignup_option_on_the_HomePage2() throws InterruptedException {
		HomePage page = new HomePage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		page.LoginSignup();
		Thread.sleep(2000);
	}
 
 @Then("^I should be able to Enter valid email address in Login2 as (.+)$")
    public void i_should_be_able_to_enter_valid_email_address_in_login2_as(String emailaddressLogin) {
	 HomePage page = new HomePage(driver);
        page.Emailid(emailaddressLogin);
    }


@And("^(.+) into password field of Login2$")
public void into_password_field_of_login2(String passwordLogin) {
    HomePage page = new HomePage(driver);
    page.Password_login(passwordLogin);
}

@And("^I should be able to Click2 on 'Login'$")
public void i_should_be_able_to_click2_on_login() throws InterruptedException {
	HomePage page = new HomePage(driver);
	page.Login();
}

@When("^I click on 'Logins/Signups' Option on the Home Page2$")
public void i_click_on_loginssignups_option_on_the_home_page2() {
	HomePage page= new HomePage(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	page.SignUpClick();
	
}

@Then("^I should Click on Facebook Icon to Login with Facebook$")
public void i_should_click_on_facebook_icon_to_login_with_facebook() {
	HomePage page = new HomePage(driver);
	page.FacebookLogin();
    
}

@When("^I click on 'Logins/Signup' Options on the Home Page2$")
public void i_click_on_loginssignup_options_on_the_home_page2() {
	HomePage page = new HomePage(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	page.SignUpClick();
    
}

@Then("^I should Click on Google Icon to Login with Facebook$")
public void i_should_click_on_google_icon_to_login_with_facebook() {
	HomePage page = new HomePage(driver);
	page.GoogleLogin();
   
}

@When("^I clicked on 'Login/Signup' Option on the Home Page2$")
public void i_clicked_on_loginsignup_option_on_the_home_page2() {
	HomePage page = new HomePage(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	page.SignUpClick();
}

@Then("^I should be able to Enter valid email address2 in email field as (.+)$")
public void i_should_be_able_to_enter_valid_email_address2_in_email_field_as(String emailaddressforgot) {
    HomePage page = new HomePage(driver);
    page.ForgotEmail(emailaddressforgot);

}

@And("^enter (.+) in password2 field1$")
public void enter_in_password2_field1(String forgotpassword) {
	HomePage page = new HomePage(driver);
	page.ForgotPassword(forgotpassword);
	
}

@And("^Click on Login option2$")
public void click_on_login_option2() throws InterruptedException {
	HomePage page = new HomePage(driver);
	page.Login();
	Thread.sleep(3000);
}

@Then("^I click on Forgot Password option$")
public void i_click_on_forgot_password_option() {
    HomePage page = new HomePage(driver);
    page.ForgotClick();
}

@Then("^I enter Email Id to send the reset password link (.+)$")
public void i_enter_email_id_to_send_the_reset_password_link(String newmail) {
    HomePage page = new HomePage(driver);
    page.ForgotMail(newmail);
}

@Then("^I click on Forgot Password to reset the password$")
public void i_click_on_forgot_password_to_reset_the_password() throws InterruptedException {
	HomePage page = new HomePage(driver);
    page.ResetClick();
    //Assert.assertEquals(driver.findElement(By.id("errCon_forgot")).getText(),"Email Sent!! Please check you inbox.");
    Assert.assertTrue(driver.findElement(By.id("errCon_forgot")).isDisplayed());
    Thread.sleep(3000);
}

@When("^I enter emailAdds2 into emailaddress field$")
public void i_enter_into_emailaddress2_field() throws InterruptedException {
 HomePage page = new HomePage(driver);
 JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	Thread.sleep(1000);
	page.Login_SignupOption();
	Thread.sleep(2000);
    page.Emailad();
}

@And("^passwd in Password2 field I should be able to login into 91Mobiles$")
public void in_password2_field_i_should_be_able_to_login_into_91mobiles() throws InterruptedException {
	HomePage page = new HomePage(driver);
    page.Passd();
    Thread.sleep(3000);
    page.Login(); 
    Thread.sleep(3000);
}




@Then("^I should be able to click on Logged in icon on Home Page$")
public void i_should_be_able_to_click_on_logged_in_icon_on_home_page() throws InterruptedException {
HomePage page = new HomePage(driver);
page.LoggedInIcon();
Thread.sleep(3000);
}

@And("^I should select My Account from the dropdown menu and redirect to My Account page$")
public void i_should_select_my_account_from_the_dropdown_menu_and_redirect_to_my_account_page() throws InterruptedException {
HomePage page = new HomePage(driver);
page.MyAccount();
Thread.sleep(2000);
}

@Then("^I should be able to change the Name and Emailid2$")
public void i_should_be_able_to_change_the_name_and_emailid2() throws InterruptedException {
HomePage page = new HomePage(driver);
page.ChangeName();
Thread.sleep(2000);
page.ChangeEmail();
Thread.sleep(2000);
}

@And("^I should click on Save changes$")
public void i_should_click_on_save_changes() throws InterruptedException {
HomePage page = new HomePage(driver);
page.SaveChanges();
Thread.sleep(2000);
}

@Given("^I change Email Id$")
public void i_change_email_id() throws InterruptedException {
HomePage page = new HomePage(driver);
page.ChangeEmail();
Thread.sleep(3000);
}

@Then("^I should be able to receive Confirmation mail when I click on send confirmation mail$")
public void i_should_be_able_to_receive_confirmation_mail_when_i_click_on_send_confirmation_mail() throws InterruptedException {
HomePage page = new HomePage(driver);
page.ConfirmMail();
Thread.sleep(2000);
}

@Given("^enter Old Password$")
public void enter_old_password() throws InterruptedException {
HomePage page = new pageobjects.HomePage(driver);
page.Oldpass();
Thread.sleep(1000);
}

@Then("^Enter New Password$")
public void enter_new_password() throws InterruptedException {
HomePage page = new HomePage(driver);
page.newpass();
Thread.sleep(1000);
}

@And("^Click on Save Password$")
public void click_on_save_password() {
HomePage page = new HomePage(driver);
page.savepass();
}

}