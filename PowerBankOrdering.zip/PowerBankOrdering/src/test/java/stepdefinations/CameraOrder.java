package stepdefinations;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.cucumber.listener.Reporter;

import base.Base;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.AllParameters;
import pageobjects.CameraSec;
import pageobjects.HomePage;

public class CameraOrder extends Base {

	WebDriver driver;

	@Before("@Camera")
	public void setup() {

		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));

	}
	
	@After("@Camera")
	public void teardown(Scenario scenario) throws IOException {
		if (scenario.isFailed()) {
			
			try 
			{
				String screenshotName = scenario.getName().replaceAll(" ", "_");
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				File screenshot_with_scenario_name = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				File destinationPath = new File("C:\\Users\\Pavithra\\eclipse-workspace\\PowerBankOrdering\\screenshots\\"+screenshotName+scenario.getId()+".png");
				
				Files.copy(screenshot_with_scenario_name.toPath(), destinationPath.toPath());
				
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
				Reporter.addScenarioLog(screenshotName);
				
				scenario.embed(screenshot, "image/png");

			} 
			
			catch (Exception e) 
			{
				
				System.out.println("Failed to take screenshot");
			
			}
		}

		driver.quit();
	}

	@Given("^I visit the 91Mobiles Website;$")
	public void i_visit_the_91mobiles_Website() {
		
		driver.get(prop.getProperty("url"));
		
	}

	@Then("^I should redirected to Homepage of the Website;$")
	public void i_should_redirected_to_homepage_of_the_website() {

		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='lets_find']")).isDisplayed());

	}

	@And("^Click on the Search bar;$")
	public void click_on_the_search_bar() {

		HomePage homepage = new HomePage(driver);
		homepage.Search();

	}

	@When("^I should be able to enter keywords;$")
	public void i_should_be_able_to_enter_keywords() {

		HomePage homepage = new HomePage(driver);
		homepage.SearchBox();
	}

	@And("^Click on enter button;$")
	public void click_on_enter_button() throws InterruptedException {

		HomePage homepage = new HomePage(driver);
		homepage.searchButton();
		
		Thread.sleep(2000);
	}
	
	//Executing Registered User TestCase
	
    @When("^I Click on Login/Signup option;$")
    public void i_click_on_loginsignup_option() throws InterruptedException {
    	
    	HomePage homepage = new HomePage(driver);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(1000);
		homepage.Login_SignupOption();
		Thread.sleep(2000);
        
    }
    @Then("^I Should enter EmailAddress and Password into required fields;$")
    public void i_should_enter_emailaddress_and_password_into_required_fields() {
    	
    	driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("muni_email"));
    	driver.findElement(By.id("password")).sendKeys(prop.getProperty("muni_password"));
    	
    }
    
    @And("^Click on Login button;$")
    public void click_on_login_button() {
        
    	HomePage homepage = new HomePage(driver);
    	homepage.Login();
    }

    @Then("^I should be redirected to Successful Login Page;$")
    public void i_should_be_redirected_to_successful_login_page() {
        
    	Assert.assertTrue(driver.findElement(By.xpath("//div[@class='msgnot']")).isDisplayed());
    	
    }

    //Keywords Scenario
    
    @Then("^I click on the Search box;$")
	public void i_click_on_the_Search_box() {
		
		HomePage homepage = new HomePage(driver);
		homepage.Search();
		
	}

    @Then("^I enter valid (.+);$")
    public void i_enter_valid(String keywords) throws InterruptedException {
    	
		switch(keywords)
		{
		case "Nikon":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("Nikon");
			
    	Thread.sleep(2000);
    	
    	break;
		
		case "10 MP & above":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("10 MP & above");
			
    	Thread.sleep(2000);
    	
    	break;
		

		case "AA Battery":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("AA Battery");
			
    	Thread.sleep(2000);
    	
    	break;
		
		}
	}

	@And("^Click on search button;$")
	public void click_on_search_button() throws InterruptedException {

		HomePage homepage = new HomePage(driver);
		homepage.searchButton();

	}

	@Then("^I should get relevant information according to (.+);$")
    public void i_should_get_relevant_information_according_to(String keywords) throws InterruptedException {

		switch(keywords)
		{
		case "Nikon":
			
			Assert.assertEquals(driver.getTitle(),"nikon | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
		
		case "10 MP & above":
			
			Assert.assertEquals(driver.getTitle(),"nikon | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
		

		case "AA Battery":
			
			Assert.assertEquals(driver.getTitle(),"nikon | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
		
		}

	}

	// Executing Invalid Testcase

    @Then("^I enter invalid (.+);$")
    public void i_enter_invalid(String keywords) throws InterruptedException {

    	switch(keywords)
		{
		case "jhscbzd":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("jhscbzd");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		case "143341":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys("143341");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		case ",./<>;'":
			
			driver.findElement(By.id("autoSuggestTxtBox")).sendKeys(",./<>;'");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		}
	}
	
    @Then("^I should get relevant page according to (.+);$")
    public void i_should_get_relevant_page_according_to(String keywords) throws InterruptedException {
		

    	switch(keywords)
		{
		case "jhscbzd":
			
			Assert.assertEquals(driver.getTitle(),"jhscbzd | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		case "143341":
			
			Assert.assertEquals(driver.getTitle(),"143341 | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		case ",./<>;'":
			
			Assert.assertEquals(driver.getTitle(),"Mobile Phones | Mobile Prices in India | Online Mobile Shopping | 91mobiles.com");
			
    	Thread.sleep(2000);
    	
    	break;
    	
		}

	}

    //Parameters Scenario
    
    @When("^I click on Camera option in Go Quickly To bar;$")
    public void i_click_on_camera_option_in_go_quickly_to_bar() {
    	
    	HomePage homepage = new HomePage(driver);
    	homepage.GoQuickly();
     
    }

    @Then("^I should redirected to camera section;$")
    public void i_should_redirected_to_camera_section() {
    
    	Assert.assertTrue(driver.findElement(By.xpath("//h1[normalize-space()='Cameras']")).isDisplayed());
       
    }

    @And("^Click on View All option;$")
    public void click_on_view_all_option() {
    	
    	CameraSec cs = new CameraSec(driver);
    	cs.ViewAll();
        
    }
    
    @Then("^Click on camera brands with (.+) and (.+);$")
    public void click_on_camera_brands_with_and(String keyword1, String keyword2) throws InterruptedException {
    
    	AllParameters ap = new AllParameters(driver);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	
		switch(keyword1)
		{
		case "Nikon":	
		
		js.executeScript("window.scrollTo(0,100)");
		ap.NikonClick();
		ap.CanonClick();

    	Thread.sleep(2000);
    	break;
		}
		
    }
    
    @And("^I should get relevant brands according to (.+) and (.+);$")
    public void i_should_get_relevant_brands_according_to_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "Nikon": 
			js.executeScript("window.scrollTo(0,-100)");
			
		if( (driver.findElement(By.xpath("//span[normalize-space()='Nikon']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='Canon']")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
    	
    }
    	
   @But("^I should not get other brand products;$")
   public void I_should_not_get_other_brand_products() {
	   
		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);
    	
    }
    
    //Executing Megapixel Testcase
    
   @Then("^Click on camera Megapixel with (.+) and (.+);$")
   public void click_on_camera_megapixel_with_and(String Keyword1, String Keyword2) throws InterruptedException  {
	   
	   AllParameters ap = new AllParameters(driver);
	   
	   switch(Keyword1)
	   {
	   case "5 MP & above":
		   
		   ap.MP1Click();
		   ap.MP2Click();
		   
		   Thread.sleep(2000);
		   break;
	   }
			   
   }
    
   @And("^I should get relevant megapixel according to (.+) and (.+);$")
   public void i_should_get_relevant_megapixel_according_to_and(String Keyword1, String Keyword2) throws InterruptedException {
	   
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "5 MP & above":
			
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//span[normalize-space()='5 MP & above']")));
			
		if( (driver.findElement(By.xpath("//span[normalize-space()='5 MP & above']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='10 MP & above']")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
 
   }
    
    @But("^I should not get other megapixel products;$")
    public void I_should_not_get_other_megapixel_products() {
    	
		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);
    	
    }
    
    //Executing Battery Testcase
    
    @Then("^Click on camera Battery with (.+) and (.+);$")
    public void click_on_camera_battery_with_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
 	   AllParameters ap = new AllParameters(driver);
 	   
 	   switch(Keyword1)
 	   {
 	   case "AA Battery":
 		   
 		   ap.AAClick();;
 		   ap.AlkalineClick();
 		   
 		   Thread.sleep(2000);
 		   break;
 	   }
    
    }
    
    @And("^I should get relevant battery according to (.+) and (.+);$")
    public void i_should_get_relevant_battery_according_to_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "AA Battery": 
			
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.cssSelector("li[data-val='pro_standard_battery_type:AA'] span")));
			
		if( (driver.findElement(By.cssSelector("li[data-val='pro_standard_battery_type:AA'] span")).isDisplayed()) && (driver.findElement(By.cssSelector("li[data-val='pro_standard_battery_type:AAA'] span")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
        
    }
    
    @But("^I should not get other battery products;$")
    public void I_should_not_get_other_battery_products() {
    	
		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);

    }
    
    //Executing Resolution Testcase
    
    @Then("^Click on camera Resolution with (.+) and (.+);$")
    public void click_on_camera_resolution_with_and(String Keyword1, String Keyword2) throws InterruptedException  {
    	
  	   AllParameters ap = new AllParameters(driver);
  	   
  	   switch(Keyword1)
  	   {
  	   case "SD":
  		   
  		   ap.SDClick();
  		   ap.HDClick();
  		   
  		   Thread.sleep(2000);
  		   break;
  	   }
    
    }

    @And("^I should get relevant resolution according to (.+) and (.+);$")
    public void i_should_get_relevant_resolution_according_to_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "SD": 
			
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(2) span:nth-child(1)")));
			
		if( (driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(2) span:nth-child(1)")).isDisplayed()) && (driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(3) span:nth-child(1)")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
        
    }

    @But("^I should not get other resolution products;$")
    public void i_should_not_get_other_resolution_products()  {
    	
		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);
     
    }

    //Executing Connectivity Testcase
    
    @Then("^Click on camera Connectivities with (.+) and (.+);$")
    public void click_on_camera_connectivities_with_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
   	   AllParameters ap = new AllParameters(driver);
   	   
   	   switch(Keyword1)
   	   {
   	   case "Wi fi":
   		   
   		   ap.WifiClick();
   		   Thread.sleep(2000);
   		   ap.HDMIClick();
   		   
   		   Thread.sleep(2000);
   		   break;
   	   }
       
    }

    @And("^I should get relevant connectivities according to (.+) and (.+);$")
    public void i_should_get_relevant_connectivities_according_to_and(String Keyword1, String Keyword2) throws InterruptedException  {
    	
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "Wi fi": 
			
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//span[normalize-space()='HDMI']")));
			
		if( (driver.findElement(By.xpath("//span[normalize-space()='Wi fi']")).isDisplayed()) && (driver.findElement(By.xpath("//span[normalize-space()='HDMI']")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
 
    }

    @But("^I should not get other connectivity products;$")
    public void i_should_not_get_other_connectivity_products() {
       
		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
		String actual = driver.getTitle();
		Assert.assertEquals(actual, expected);
     
    }
    
    //Executing Zoom Testcase

    @Then("^Click on camera Zoom with (.+) and (.+);$")
    public void click_on_camera_zoom_with_and(String Keyword1, String Keyword2) throws InterruptedException  {
    	
    	   AllParameters ap = new AllParameters(driver);
       	   
       	   switch(Keyword1)
       	   {
       	   case "5x & above":
       		  
       		   ap.Zoom1Click();
       		   ap.Zoom2Click();
       		   
       		   Thread.sleep(2000);
       		   break;
       	   }
             
    }

    @And("^I should get relevant zoom according to (.+) and (.+);$")
    public void i_should_get_relevant_zoom_according_to_and(String Keyword1, String Keyword2) throws InterruptedException {
    	
		String expected = "true";
		String actual = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch(Keyword1)
		{
		case "5x & above": 
			
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(2) span:nth-child(1)")));
			
		if( (driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(2) span:nth-child(1)")).isDisplayed()) && (driver.findElement(By.cssSelector("div[id='filter_list'] li:nth-child(3) span:nth-child(1)")).isDisplayed()))
		{
			actual="true";
		}
		else
			actual="false";
		break;
		}
		
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);

    }

    @Then("^I should not get other zoom products;$")
    public void i_should_not_get_other_zoom_products()  {
        
 		String expected = "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com";
 		String actual = driver.getTitle();
 		Assert.assertEquals(actual, expected);
    }
    
    //Details Scenario
    
    @And("^I click on camera in Go Quickly to bar;$")
    public void i_click_on_camera_in_go_quickly_to_bar()  {
    
    	HomePage homepage = new HomePage(driver);
    	homepage.GoQuickly();
    	
    }
    
    @Then("^I should get camera catalog;$")
    public void i_should_get_camera_catalog() {
      
    	CameraSec cs = new CameraSec(driver);
    	cs.ViewAll();
    	
    }
    
    @When("^I click on camera product;$")
    public void i_click_on_Camera_product() {
    	
    	HomePage hp = new HomePage(driver);
    	hp.ProductClick();
    			
    }

    @Then("^I should redirect to selected product description page;$")
    public void i_should_redirect_to_selected_product_description_page() throws InterruptedException {
    
    	  Set<String> id = driver.getWindowHandles();
  	  		Iterator<String> itr = id.iterator();
  	  		@SuppressWarnings("unused")
  			String mainw = itr.next();
  	  		String child = itr.next();
  	  		driver.switchTo().window(child);
  	  		
    	String actual = driver.findElement(By.xpath("//span[@class='flt-lft spec_titl']")).getText();
		String expected = "Key Specs";
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
    }
    
    @And("^I click on Camera images;$")
    public void i_click_on_camera_images() {
    	
    	Assert.assertTrue(driver.findElement(By.id("mainImage")).isDisplayed());
    
    }
    
    //Executing price test case
    
    @And("^Price of the product should be displayed;$")
    public void price_of_the_product_should_be_displayed() throws InterruptedException {
    	
    	Assert.assertTrue(driver.findElement(By.id("mainImage")).isDisplayed());
    
    	Thread.sleep(2000);
    }
    
    //Executing features test case
    
    @When("^I click on View Full Specifications option;$")
    public void i_click_on_view_full_specifications_option() throws InterruptedException {
    
  	  Set<String> id = driver.getWindowHandles();
	  		Iterator<String> itr = id.iterator();
	  		@SuppressWarnings("unused")
			String mainw = itr.next();
	  		String child = itr.next();
	  		driver.switchTo().window(child);
	  		
    	HomePage hp = new HomePage(driver);
    	hp.SpecCheck();
    	
    	Thread.sleep(3000);
    }

    @Then("^Full specifications of the product should be displayed;$")
    public void full_specifications_of_the_product_should_be_displayed() throws InterruptedException {
    	
    	Assert.assertTrue(driver.findElement(By.cssSelector("div[id='spec_response'] h2[class='heading head_bdr']")).isDisplayed());
    
    	Thread.sleep(1000);
    }
    
    //Ordering Scenario
    
    @And("^Camera option in Go Quickly To should be clicked;$")
    public void camera_option_in_go_quickly_to_should_be_clicked() {
        
    	HomePage homepage = new HomePage(driver);
    	homepage.GoQuickly();
    	
    }
    
    @Then("^Camera Catalog should be displayed;$")
    public void camera_catalog_should_be_displayed() {
    	
      	CameraSec cs = new CameraSec(driver);
      	cs.ViewAll();
      	
    }
    
    @When("^I select a Camera product;$")
    public void i_select_a_camera_product() {
    	
    	HomePage homepage = new HomePage(driver);
    	homepage.ProductClick();
    	
    }
    
    @Then("^I should be redirected to description page;$")
    public void i_should_be_redirected_to_description_page() throws InterruptedException  {
    	
  	  Set<String> id = driver.getWindowHandles();
	  		Iterator<String> itr = id.iterator();
	  		@SuppressWarnings("unused")
			String mainw = itr.next();
	  		String child = itr.next();
	  		driver.switchTo().window(child);
    	
	  		String actual = driver.findElement(By.xpath("//span[@class='flt-lft spec_titl']")).getText();
			String expected = "Key Specs";
		Assert.assertEquals(actual, expected);
		
		Thread.sleep(2000);
		
    }
    
    @And("^Click on Go to Store option;$")
    public void click_on_go_to_store_option() throws Throwable {
    
  	  Set<String> id = driver.getWindowHandles();
	  		Iterator<String> itr = id.iterator();
	  		@SuppressWarnings("unused")
			String mainw = itr.next();
	  		String child2 = itr.next();
	  		driver.switchTo().window(child2);
    	
    	AllParameters ap = new AllParameters(driver);
    	ap.StoreClick();
    	
    }

    @Then("^I should be redirected to desired website for confirmation;$")
    public void i_should_be_redirected_to_desired_website_for_confirmation() throws InterruptedException {
    
    	Set<String> id = driver.getWindowHandles();
  		Iterator<String> itr = id.iterator();
  		@SuppressWarnings({ "unused" })
		String mainw = itr.next();
  		@SuppressWarnings("unused")
		String child = itr.next();
  		String child2 = itr.next();
  		driver.switchTo().window(child2);
  	  		
    	String actual = driver.getTitle();
		String expected = "Instant Cameras Online – Buy Fujifilm Instax Camera at Best Price | Paytm";
		Thread.sleep(3000);
		Assert.assertEquals(actual, expected);
		
    }
      
    //Executing Register test case
    
    @When("^I click on Login option;$")
    public void i_click_on_login_option() throws InterruptedException {
    
    	HomePage homepage = new HomePage(driver);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(1000);
		homepage.Login_SignupOption();
		Thread.sleep(2000);
    	
    }

    @Then("^I enter EmailAddress and Password into required fields;$")
    public void i_enter_emailaddress_and_password_into_required_fields() {
     
    	driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("muni_email"));
    	driver.findElement(By.id("password")).sendKeys(prop.getProperty("muni_password"));
    	
    }

    @And("^Click on Login option;$")
    public void click_on_login_option() {
    	
    	HomePage homepage = new HomePage(driver);
    	homepage.Login();
    	
    }
    
    @Then("^Login Successful page should be displayed;$")
    public void login_successful_page_should_be_displayed() {
    
    	Assert.assertTrue(driver.findElement(By.xpath("//div[@class='msgnot']")).isDisplayed());
    	
    }
    
}