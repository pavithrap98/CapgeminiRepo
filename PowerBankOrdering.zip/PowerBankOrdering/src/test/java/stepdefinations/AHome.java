package stepdefinations;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.cucumber.listener.Reporter;

import base.Base;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import pageobjects.HomePage;

@RunWith(Cucumber.class)
public class AHome extends Base{
	WebDriver driver;

	@Before("@test")
	public void setup() {
		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));
	}

	@After("@test")
	public void teardown(Scenario scenario) throws IOException {
		if (scenario.isFailed()) {
			try {
				String screenshotName = scenario.getName().replaceAll(" ", "_");
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				File screenshot_with_scenario_name = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				File destinationPath = new File("C:\\Users\\Pavithra\\eclipse-workspace\\PowerBankOrdering\\screenshots\\"+screenshotName+scenario.getId()+".png");
				
				Files.copy(screenshot_with_scenario_name.toPath(), destinationPath.toPath());
				
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
				Reporter.addScenarioLog(screenshotName);
				
				scenario.embed(screenshot, "image/png");

			} catch (Exception e) {
				System.out.println("Failed to take screenshot");
			}
		}

		driver.quit();
	}


    @Given("^Enter the URL of 91Mobiles Website.$")
    public void enter_the_url_of_91mobiles_website() {
    	driver.get(prop.getProperty("url"));
    }

    @When("^I click on languages Option.$")
    public void i_click_on_languages_option() throws InterruptedException {
    	HomePage page = new HomePage(driver);
		page.Dropdown();
		Thread.sleep(3000);
    }

    @Then("^I should access the home page.$")
    public void i_should_access_the_home_page() {
    	Assert.assertTrue(driver.findElement(By.cssSelector("img[title='#1 Mobile Portal India | 91mobiles.com'][alt='Mobile Price India | 91mobiles.com'][width='auto']")).isDisplayed());
    	driver.getTitle();
		String Title = driver.getTitle();
		System.out.println(Title);
	}
    

    @Then("^I should select languages (.+) option.$")
    public void i_should_select_languages_option(String lang) {
    	HomePage page = new HomePage(driver);
    	switch(lang)
    	{
    	case "Hindi": page.Hindi(); break;
    	case "Tamil": page.Tamil(); break;
    	case "English": page.English(); break;
    	
    	}
        
    }

    @And("^I should get content according to (.+).$")
    public void i_should_get_content_according_to(String lang) {
    	switch(lang)
    	{
    	case "Hindi": Assert.assertEquals(driver.findElement(By.linkText("टॉप 10 मोबाइल्स")).getText(), "टॉप 10 मोबाइल्स"); break;
    	case "Tamil": Assert.assertEquals(driver.findElement(By.linkText("டாப் 10 மொபைல்கள்")).getText(), "டாப் 10 மொபைல்கள்"); break;
    	case "English": Assert.assertEquals(driver.findElement(By.linkText("Top 10")).getText(), "Top 10"); break;
    	
    	}
    }
    	
    	@When("^I click on Mobiles Option in Go Quickly.$")
    	public void i_click_on_mobiles_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.Mobiles();
    		Thread.sleep(1000);
    		

    	}
    	
    	@Then("^I should redirected to Mobiles Catalog.$")
    	public void i_should_redirected_to_mobiles_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Mobiles Online in India | Phone Reviews, Deals, News & Videos | 91mobiles.com");

    	}
    	
    	@And("^I click on 91Mobiles logo.$")
    	public void i_click_on_91mobiles_logo() {
    		HomePage page = new HomePage(driver);
    		page.HomepageLogo();
    	}
    	
    	@When("^I click on Laptop Option in Go Quickly.$")
    	public void i_click_on_laptop_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.Laptops();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Laptops Catalog.$")
    	public void i_should_redirected_to_laptops_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Laptops Online in India | Laptop Reviews, Deals & News | 91mobiles.com");

    	}
    	
    	@When("^I click on Tablets Option in Go Quickly.$")
    	public void i_click_on_tablets_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.Tablets();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Tablets Catalog.$")
    	public void i_should_redirected_to_tablets_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Tablets Online in India | Tablet Reviews, Deals & News | 91mobiles.com");

    	}
    	
    	@When("^I click on Cameras Option in Go Quickly.$")
    	public void i_click_on_cameras_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.Cameras();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Cameras Catalog.$")
    	public void i_should_redirected_to_cameras_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Cameras Online in India | Camera Reviews, Deals & News | 91mobiles.com");
    	}
    	
    	@When("^I click on Television Option in Go Quickly.$")
    	public void i_click_on_television_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.Television();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Television Catalog.$")
    	public void i_should_redirected_to_television_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Televisions Online in India | TV Reviews, Deals & News | 91mobiles.com");
    	}
    	
    	 @When("^I click on Home Theaters Option in Go Quickly.$")
    	    public void i_click_on_home_theaters_option_in_go_quickly() throws InterruptedException {
    		 	HomePage page = new HomePage(driver);
    		 	page.HomeTheaters();
    		 	Thread.sleep(1000);
    	        
    	    }

    	    @Then("^I should redirected to Home Theaters Catalog.$")
    	    public void i_should_redirected_to_home_theaters_catalog() {
    	    	Assert.assertEquals(driver.getTitle(),"Home Theaters Finder - Buy Best Home Theater by Brand, Price, Type | 91mobiles.com");
    	    }
    	
    	@When("^I click on Power Banks Option in Go Quickly.$")
    	public void i_click_on_power_banks_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.PowerBanks();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Power Banks Catalog.$")
    	public void i_should_redirected_to_power_banks_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Power banks Online in India | Portable Charger Reviews, Deals & News | 91mobiles.com");
    	}
    	
    	@When("^I click on Smart Watches Option in Go Quickly.$")
    	public void i_click_on_smart_watches_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.SmartWatches();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Smart Watches Catalog.$")
    	public void i_should_redirected_to_smart_watches_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Smartwatch Finder : Find the best Smartwatch that suits your needs | 91mobiles.com");

    	}
    	
    	@When("^I click on Washing Machines Option in Go Quickly.$")
    	public void i_click_on_washing_machines_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.WashingMachines();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Washing Machines Catalog.$")
    	public void i_should_redirected_to_washing_machines_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Washing Machines Online in India | Washing Machine Reviews, Deals & News | 91mobiles.com");

    	}
    	
    	@When("^I click on Air Conditioners Option in Go Quickly.$")
    	public void i_click_on_air_conditioners_option_in_go_quickly() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.AirConditioners();
    		Thread.sleep(1000);

    	}

    	@Then("^I should redirected to Air Conditioners Catalog.$")
    	public void i_should_redirected_to_air_conditioners_catalog() {
    		Assert.assertEquals(driver.getTitle(),"Buy Air Conditioners Online in India | AC Reviews, Deals & News | 91mobiles.com");

    	}
    	
    	@When("^I Click on the Login/SignUp option.$")
    	public void i_click_on_the_loginsignup_option() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
    		page.LoginSignup();
    		Thread.sleep(2000);

    	}

    	@Then("^I should login with valid credentials.$")
    	public void i_should_login_with_valid_credentials() {
    		HomePage page = new HomePage(driver);
    		driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("Akash_user"));
    		driver.findElement(By.id("password")).sendKeys(prop.getProperty("Akash_password"));
    		page.Login();

    	}

    	@And("^I should access the home page as registered User.$")
    	public void i_should_access_the_home_page_as_registered_user() {
    		Assert.assertTrue(
    				driver.findElement(By.xpath("//div[@class='notify_wrap']//div[@class='fav_notify']")).isDisplayed());

    	}
    	
    	 @When("^I click on (.+) from footer.$")
    	    public void i_click_on_from_footer(String keyword) throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
    		
    	switch(keyword) {
    	case "AboutUs": page.AboutUs();
    	Thread.sleep(2000);
    	break;
    	case "ContactUs": page.ContactUs();
    	Thread.sleep(2000);
    	break;
    	case "TermsConditions": page.TermsConditions();
    	Thread.sleep(2000);
    	break;
    	case "Privacy": page.Privacy();
    	Thread.sleep(2000);
    	break;
    	case "Feedback": page.Feedback();
    	Thread.sleep(2000);
    	break;
    	case "Home": page.Home();
    	Thread.sleep(2000);
    	break;
    	case "Sitemap": page.Sitemap();
    	Thread.sleep(2000);
    	break;
    
    	}
    	
    		
    	}

    	@Then("^I should Redirect to relevent Page based on (.+).$")
        public void i_should_redirect_to_relevent_page_based_on(String keyword) {
    		switch(keyword) {
        	case "AboutUs": Assert.assertEquals(driver.getTitle(), "About Us | 91mobiles.com");
        	break;
        	case "ContactUs": Assert.assertEquals(driver.getTitle(), "Contact Us | 91mobiles.com");
        	break;
        	case "TermsConditions": Assert.assertEquals(driver.getTitle(), "Terms and Conditions | 91mobiles.com");
        	break;
        	case "Privacy": Assert.assertEquals(driver.getTitle(), "Privacy Policy | 91mobiles.com");
        	break;
        	case "Feedback": Assert.assertEquals(driver.getTitle(), "Contact Us | 91mobiles.com");
        	break;
        	case "Home": Assert.assertEquals(driver.getTitle(), "Mobile Phones | Mobile Prices in India | Online Mobile Shopping | 91mobiles.com");
        	break;
        	case "Sitemap": Assert.assertEquals(driver.getTitle(), "Sitemap | 91mobiles.com");
        	break;
        	
        	}
            
        }
    	
    	@When("^I set the limits by adjusting the slider.$")
    	public void i_set_the_limits_by_adjusting_the_slider() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		WebElement max = page.Max();
    		WebElement min = page.Min();
    		
    		Actions a = new Actions(driver);
    		a.dragAndDropBy(min, 50, 0).perform();
    		Thread.sleep(2000);
    		a.dragAndDropBy(max, -500, 0).perform();
    	}
    	
    	@Then("^I should click on Find Mobile.$")
    	public void i_should_click_on_find_mobile() {
    		HomePage page = new HomePage(driver);
    		page.FindMobile();

    	}
    	
    	@And("^I should get products around the price range.$")
        public void i_should_get_products_around_the_price_range() {
    		Assert.assertTrue(driver.findElement(By.xpath("//body/div/div[@class='outer_wrap content_wrap']/form[@id='phonefinder']/div[@class='content_wrap_inner top10_content_wrap_inner']/div[@class='new-finder-wrapper2 order2']/div[@id='new-finder-right-content']/div[@class='new-finder-right']/div[@id='finderResults']/div[4]/div[1]/div[2]/div[2]/div[1]/span[1]")).isDisplayed());
            
        }
    	
    	
    	@When("^I Enter (.+) in to the Search box.$")
    	public void i_enter_in_to_the_search_box(String keywords) throws InterruptedException {

    		driver.findElement(By.id("autoSuggestTxtBox")).sendKeys(keywords);
    		Thread.sleep(3000);
    	}

    	@Then("^I click on search button.$")
    	public void i_click_on_search_button() throws InterruptedException {
    		HomePage page = new HomePage(driver);
    		page.searchButton();

    	}

        @And("^I should get the (.+) accordingly.$")
        public void i_should_get_the_accordingly(String expectedresults) throws InterruptedException {
        	String actualresult = null;

    		Thread.sleep(2000);
    		if (driver.findElement(By.xpath("//div[@class='noserch_title']")).getText().equals("Sorry, no results found")) {
    			actualresult = "failure";
    		} else
    			actualresult = "success";

    		Assert.assertEquals(actualresult, expectedresults);

        }
        
    	
    	@When("^I should Select Top Categories (.+) options.$")
    	public void i_should_select_top_categories_options(String products) {
    		HomePage page = new HomePage(driver);
    		switch (products) {
    		case "mobiles":
    			page.mobiles();
    			break;
    		case "laptops":
    			page.laptops();
    			break;
    		case "tablets":
    			page.tablets();
    			break;
    		case "audio":
    			page.audio();
    			break;
    		case "smartwatches":
    			page.smartwatches();
    			break;
    		case "televisions":
    			page.televisions();
    			break;
    		case "airconditioners":
    			page.airconditioners();
    			break;
    		case "refrigerators":
    			page.refrigerators();
    			break;
    		case "washingmachines":
    			page.washingmachines();
    			break;
    		case "cameras":
    			page.cameras();
    			break;
    		}
    	}

    	@And("^I should get the content according to that (.+).$")
    	public void i_should_get_the_content_according_to_that(String products) {
    		switch (products) {
    		case "mobiles":
    			Assert.assertEquals(driver.getTitle(),"Buy Mobiles Online in India | Phone Reviews, Deals, News & Videos | 91mobiles.com");
    			break;
    		case "laptops":
    			Assert.assertEquals(driver.getTitle(),"Buy Laptops Online in India | Laptop Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "tablets":
    			Assert.assertEquals(driver.getTitle(),"Buy Tablets Online in India | Tablet Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "audio":
    			Assert.assertEquals(driver.getTitle(),"Buy Audio Products Online in India | Earphones, Headphones & Earbuds Deals & News | 91mobiles.com");
    			break;
    		case "smartwatches":
    			Assert.assertEquals(driver.getTitle(),"Buy Wearables Online in India | Smartwatch & Smartband Prices,Specs & News | 91mobiles.com");
    			break;
    		case "televisions":
    			Assert.assertEquals(driver.getTitle(),"Buy Televisions Online in India | TV Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "airconditioners":
    			Assert.assertEquals(driver.getTitle(),"Buy Air Conditioners Online in India | AC Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "refrigerators":
    			Assert.assertEquals(driver.getTitle(),"Buy Refrigerators Online in India | Refrigerator Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "washingmachines":
    			Assert.assertEquals(driver.getTitle(),"Buy Washing Machines Online in India | Washing Machine Reviews, Deals & News | 91mobiles.com");
    			break;
    		case "cameras":
    			Assert.assertEquals(driver.getTitle(),"Buy Cameras Online in India | Camera Reviews, Deals & News | 91mobiles.com");
    			break;
    		}
    	}



}