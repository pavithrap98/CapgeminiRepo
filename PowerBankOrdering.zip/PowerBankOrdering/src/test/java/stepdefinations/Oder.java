package stepdefinations;

import java.io.File;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.Set;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.Reporter;

import base.Base;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;
import pageobjects.Cameras;
import pageobjects.Canon;
import pageobjects.HomePage;
import pageobjects.PowerBanks;

@RunWith(Cucumber.class)
public class Oder extends Base {

	WebDriver driver;

	@Before("@order")
	public void setup() {

		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));

	}
	
	@After("@order")
	public void tearDown(Scenario scenario) {
		if (scenario.isFailed()) {
			try {
				String screenshotName = scenario.getName().replaceAll(" ", "_");
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				File screenshot_with_scenario_name = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

				File destinationPath = new File("C:\\Users\\Pavithra\\eclipse-workspace\\PowerBankOrdering\\screenshots\\"+screenshotName+scenario.getId()+".png");

				Files.copy(screenshot_with_scenario_name.toPath(), destinationPath.toPath());

				Reporter.addScreenCaptureFromPath(destinationPath.toString());
				Reporter.addScenarioLog(screenshotName);

				scenario.embed(screenshot, "image/png");

			} catch (Exception e) {
				System.out.println("Failed to take screenshot");
			}
		}
		driver.quit();
	}

	@Given("^I visit the application$")
	public void i_visit_the_application() {
		driver.get(prop.getProperty("url"));
	}

	@Then("^I should redirect to home page of the application$")
	public void i_should_redirect_to_home_page_of_the_website() {
		Assert.assertTrue(driver.findElement(By.xpath("//img[@width='auto']")).isDisplayed());
	}

	@And("^I should be able to enter keyword on search bar$")
	public void i_should_be_able_to_enter_keyword_on_search_bar() throws InterruptedException {
		HomePage page = new HomePage(driver);
		page.SearchBars();
	}

	@When("^I clicked on Search on search bar$")
	public void i_click_on_search_on_search_bar() throws InterruptedException {
		HomePage page = new HomePage(driver);
		page.searchButton();
	}

	@When("^I click on particular product$")
	public void i_click_on_particular_product() throws InterruptedException {
		Canon page = new Canon(driver);
		page.Product();
	}

	@When("^I click on the go to store option displayed on product display page$")
	public void i_click_on_the_go_to_store_option_displayed_on_product_display_page() {
		driver.findElement(By.xpath("//img[@title='Buy @ Flipkart']")).click();
	}

	@Then("^I should get search resultss$")
	public void i_should_get_search_results() {
		Assert.assertEquals(driver.getTitle(), "nikon d5600 | 91mobiles.com");
	}

	@Then("^I should redirect to that particular product display page$")
	public void i_should_redirect_to_that_particular_product_display_page() {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		String child = itr.next();
		driver.switchTo().window(child);
		Assert.assertEquals(driver.getTitle(), "Nikon D5600 (AF-P 18-55mm f/3.5-f/5.6G VR Kit Lens) Digital SLR Camera Price in India on 19th Jul 2021 | 91mobiles.com");
	}

	@Then("^I should redirect to that particular store$")
	public void i_should_redirect_to_that_particular_store() throws InterruptedException {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		@SuppressWarnings("unused")
		String child = itr.next();
		String child2 = itr.next();
		driver.switchTo().window(child2);
		Thread.sleep(5000);
		Assert.assertEquals(driver.getTitle(), "NIKON D5600 DSLR Camera Body with Single Lens: AF-P DX Nikkor 18-55 MM F/3.5-5.6G VR (16 GB SD Card) Price in India - Buy NIKON D5600 DSLR Camera Body with Single Lens: AF-P DX Nikkor 18-55 MM F/3.5-5.6G VR (16 GB SD Card) online at Flipkart.com");
	}

	@When("^I Click on the Login/SignUp option$")
	public void i_click_on_the_loginsignup_option() throws InterruptedException {
		HomePage page = new HomePage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(1000);
		page.Login_SignupOption();
		Thread.sleep(2000);

	}

	@Then("^I should login with valid credentialsss$")
	public void i_should_login_with_valid_credentials() {
		HomePage page = new HomePage(driver);
		driver.findElement(By.id("emailId")).sendKeys(prop.getProperty("girish_username"));
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("girish_password"));
		page.login();
	}

	@And("^I should access the home page as registered Userss$")
	public void i_should_access_the_home_page_as_registered_user() {
		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='notify_wrap']//div[@class='fav_notify']")).isDisplayed());
	}

	@When("^I click on the See Full Specs displayed on product display page$")
	public void i_click_on_the_see_full_specs_displayed_on_product_display_page() {
		Canon page = new Canon(driver);
		page.Specifications();

	}

	@Then("^I should redirect to Specifications$")
	public void i_should_redirect_to_specifications() {
		String Spec = driver.findElement(By.xpath("//div[@id='spec_response']//h2[@class='heading head_bdr']")).getText();
		Assert.assertEquals(Spec, "CANON EOS 1500D (EF-S 18-55MM F/3.5-F/5.6 IS II KIT LENS) DIGITAL SLR CAMERA SPECIFICATIONS");
	}

	@When("^I click on Fast charging powerbanks$")
	public void i_click_on_fast_charging_powerbanks() {
		PowerBanks page =  new PowerBanks(driver);
		page.fastChargingPowerBank();
	}
	
	@When("^I click on Mi PowerBank product$")
	public void i_click_on_mi_powerbank_product() {
		driver.findElement(By.linkText("Xiaomi Mi Power Bank 3i 10000 mAh Power Bank")).click();
	}
	
	@Then("^I should redirect to that product display page$")
	public void i_should_redirect_to_that_product_display_page() {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		String child = itr.next();
		driver.switchTo().window(child);
		Assert.assertEquals(driver.getTitle(), "Xiaomi Mi Power Bank 3i 10000 mAh Power Bank price in India | 91mobiles.com");
	}
	
	@Then("^I should get power bank catalog$")
	public void i_should_get_power_bank_catalog() {
		Assert.assertEquals(driver.getTitle(), "Buy Power banks Online in India | Portable Charger Reviews, Deals & News | 91mobiles.com");
	}

	@Then("^I should get the List of Powerbanks$")
	public void i_should_get_the_list_of_powerbanks() {
		Assert.assertEquals(driver.getTitle(), "Fast Charging Power Banks in India with Price (20th July 2021) | 91mobiles.com");
	}

	@And("^I should be able to click on Power Banks in Go Quickly To option$")
	public void i_should_be_able_to_click_on_power_banks_in_go_quickly_to_option() {
		HomePage page = new HomePage(driver);
		page.powerBank();
	}
	
	@Then("^I should redirect to that store$")
	public void i_should_redirect_to_that_store() throws Throwable {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		@SuppressWarnings("unused")
		String child = itr.next();
		String child2 = itr.next();
		driver.switchTo().window(child2);
		Assert.assertEquals(driver.getTitle(), "Mi 3i 10000 mAh Power Bank (Fast Charging, 18W) Price in India - Buy Mi 3i 10000 mAh Power Bank (Fast Charging, 18W) online at Flipkart.com");
	}
	
	@When("^I click on Nikon in Cameras in Popular Brands panel$")
	public void i_click_on_nikon_in_cameras_in_popular_brands_panel() {
		Cameras page = new Cameras(driver);
		page.brandNikon();
	}

	@When("^I click on Nikon D5600 camera$")
	public void i_click_on_nikon_d5600_camera() {
		driver.findElement(By.xpath("//img[@title='Nikon D5600 (AF-P DX 18-55mm f/3.5-f/5.6G VR and AF-P DX 70-300mm f/4.5-f/6.3G ED VR Dual Kit Lens) Digital SLR Camera']")).click();
	}

	@Then("^I should get Camera catalog$")
	public void i_should_get_camera_catalog() {
		Assert.assertEquals(driver.getTitle(), "Buy Cameras Online in India | Camera Reviews, Deals & News | 91mobiles.com");
	}

	@Then("^I should get Cameras of that Brand$")
	public void i_should_get_cameras_of_that_brand() {
		Assert.assertEquals(driver.getTitle(), "Camera Finder in India: Select Best Camera by Brand, Type, Price, Feature | 91mobiles.com");
	}

	@Then("^I should redirect to Product display page of D5600 Camera$")
	public void i_should_redirect_to_product_display_page_of_d5600_camera() {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		String child = itr.next();
		driver.switchTo().window(child);
		Assert.assertEquals(driver.getTitle(), "Nikon D5600 (AF-P DX 18-55mm f/3.5-f/5.6G VR and AF-P DX 70-300mm f/4.5-f/6.3G ED VR Dual Kit Lens) Digital SLR Camera Price in India on 19th Jul 2021 | 91mobiles.com");
	}

	@Then("^I should be able to redirect to that store$")
	public void i_should_be_able_to_redirect_to_that_store() {
		Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		@SuppressWarnings("unused")
		String child = itr.next();
		String child2 = itr.next();
		driver.switchTo().window(child2);
		Assert.assertEquals(driver.getTitle(), "NIKON D5600 DSLR Camera Body with Dual Lens: AF-P DX Nikkor 18 - 55 MM F/3.5-5.6G VR and 70-300 MM F/4.5-6.3G ED VR Price in India - Buy NIKON D5600 DSLR Camera Body with Dual Lens: AF-P DX Nikkor 18 - 55 MM F/3.5-5.6G VR and 70-300 MM F/4.5-6.3G ED VR online at Flipkart.com");
	}

	@And("^I should be able to click on Cameras in Top Categories panel$")
	public void i_should_be_able_to_click_on_cameras_in_top_categories_panel() {
		driver.findElement(By.xpath("//div[@class='category-sprite cameras-icn']")).click();
	}
	
	@When("^I click on the favourite products logo on HomePage$")
    public void i_click_on_the_favourite_products_logo_on_homepage() {
        HomePage page = new HomePage(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
    	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        page.favourites();
    }

    @When("^I click on the the product which is in favourites$")
    public void i_click_on_the_the_product_which_is_in_favourites() {
        driver.findElement(By.xpath("//li[@class='li_fav']//div[@class='product_img']")).click();
    }

    @Then("^I should redirect to favourite page$")
    public void i_should_redirect_to_favourite_page() {
        Assert.assertEquals(driver.getTitle(), "My Account | 91mobiles.com");
    }

    @Then("^I should redirect to product display page$")
    public void i_should_redirect_to_product_display_page() {
    	Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		String child = itr.next();
		driver.switchTo().window(child);
		Assert.assertEquals(driver.getTitle(), "Samsung Galaxy F62 Price in India, Full Specs (19th July 2021) | 91mobiles.com");
    }
    
    @Then("^I should redirect to store$")
    public void i_should_redirect_to_store() {
    	Set<String> id = driver.getWindowHandles();
		Iterator<String> itr = id.iterator();
		@SuppressWarnings("unused")
		String mainw = itr.next();
		@SuppressWarnings("unused")
		String child = itr.next();
		String child2 = itr.next();
		driver.switchTo().window(child2);
		Assert.assertEquals(driver.getTitle(), "SAMSUNG Galaxy F62 ( 128 GB Storage, 6 GB RAM ) Online at Best Price On Flipkart.com");
    }
    
    @And("^I should enter the (.+) on the search bar$")
    public void i_should_enter_the_on_the_search_bar(String keywords) {
    	driver.findElement(By.id("autoSuggestTxtBox")).sendKeys(keywords);
    }
    
    @Then("^I should get the results based on expected (.+)$")
    public void i_should_get_the_results_based_on_expected(String expectedresults) throws InterruptedException {
    	String actualresult = null;
		Thread.sleep(2000);
		if (driver.findElement(By.xpath("//div[@class='noserch_title']")).getText().equals("Sorry, no results found")) {
			actualresult = "failure";
		} 
		else
			actualresult = "success";
		Assert.assertEquals(actualresult, expectedresults);
    }
    
}
