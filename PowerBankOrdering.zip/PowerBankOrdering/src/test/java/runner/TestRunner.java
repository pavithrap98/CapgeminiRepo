package runner;

import java.io.File;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"com.cucumber.listener.ExtentCucumberFormatter:target/html/ExtentReport.html"},features="features",
glue="stepdefinations",tags= {"@Camera,@search,@order,@MyAccount,@test"}, monochrome=true)
public class TestRunner extends AbstractTestNGCucumberTests {
	
	@AfterClass()
	public static void extentreport() throws IOException {	
		
	String projectPath = System.getProperty("user.dir");		
	Reporter.loadXMLConfig(new File(projectPath+"\\src\\test\\java\\extent-config.xml"));
	Reporter.setSystemInfo("User Name", "Pavithra P");
	Reporter.setSystemInfo("Application Name", "91 Mobiles");
	Reporter.setSystemInfo("Operating System Type", System.getProperty("os.name").toString());
	Reporter.setSystemInfo("Environment", "Test Environment");
	Reporter.setTestRunnerOutput("Test Execution Cucumber Report");
	
	}
	
	
	
}
