package stepdefinition;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import base.Base;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
public class register extends Base{
	WebDriver driver;
	
	@Before("@test")
	public void setup() {

		loadProjectDataProperties();
		driver = initializeBrowser(prop.getProperty("browser"));

	}

    @Given("^I visited 99 acres website$")
    public void i_visited_99_acres_website() {
    	driver.get(prop.getProperty("url"));
        
    }

    @When("^I Clicked on Menubar$")
    public void i_clicked_on_menubar() {
        
    }

    @When("^I clicked on Register option$")
    public void i_clicked_on_register_option() {
      
    }

    @Then("^I Clicked on LoginandRegister$")
    public void i_clicked_on_loginandregister() {
        
    }

    @Then("^I entered my name$")
    public void i_entered_my_name() {
        
    }

    @Then("^i clicked on Register$")
    public void i_clicked_on_register() {
        
    }

    @Then("^i entered My otp$")
    public void i_entered_my_otp() {
       
    }

    @And("^Email$")
    public void email() {
        
    }

    @And("^Password$")
    public void password() {
      
    }

    @And("^phone number$")
    public void phone_number() {
        
    }

    @And("^clicked on Verify$")
    public void clicked_on_verify() {
       
    }

}